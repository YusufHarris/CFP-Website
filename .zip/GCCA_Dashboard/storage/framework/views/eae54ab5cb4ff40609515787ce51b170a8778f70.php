<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>CFP Dashboard</title>
    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
