<script>
// Use regex to add commas to a number
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Get the sector beneficiary data
var data = <?php echo json_encode( $sectorBens ) ?>;

// Create the SVG object to store the pie chart
var w = 400,
    h = 400;
var svg = d3.select("#sectorPie").append("svg").attr("width",w).attr("height",h),
    radius = Math.min(w, h) / 2,
    g = svg.append("g").attr("transform", "translate(" + w / 2 + "," + h / 2 + ")"),
    outRadius = radius - 10,
    inRadius = radius * 0.4,
    outRadiusOver = radius + 1,
    inRadiusOver = radius * 0.36,
    labelRadius = radius * 0.65;

// Set the colors for the sectors of the pie chart
var color = d3.scaleOrdinal(["#eeee66", "#ff6666", "#55dd55", "#5599dd"]);

// Create the pie chart using the beneficiary numbers
var pie = d3.pie()
    .sort(null)
    .value(function(d) { return d.totalBeneficiaries; });

// Create the path of the pie chart
var path = d3.arc()
    .outerRadius(outRadius)
    .innerRadius(inRadius);

// Create the path of the pie chart when it first loads
var pathLoad = d3.arc().outerRadius(outRadius).innerRadius(outRadius * 0.99)

// Create the path of the pie chart when the mouse is over it
var pathOver = d3.arc().outerRadius(outRadiusOver).innerRadius(inRadiusOver);

// Create the Label locations within the pie chart
var secLabel = d3.arc()
    .outerRadius(labelRadius)
    .innerRadius(labelRadius);

// Create the central circle to click to show all Beneficiaries
var circ = g.append("circle")
    .attr("r", inRadius)
    .attr("fill", "white")

// Create the arc to traverse the pie chart
var arc = g.selectAll(".arc")
    .data(pie(data))
    .enter().append("g")
    .attr("class", "arc");

d3.selectAll("path").transition()
    .duration(750)
    .delay(10)
    .attr("d", path);

  // Fill in the sections of the pie chart with the corresponding colors
arc.append("path")
    .attr("d", pathLoad)
    .attr("fill", function(d) { return color(d.data.sector); })
    .on("mouseover",function(d,i){
        d3.select(this)
        .transition()
        .duration(300)
        .attr("d", pathOver);
    })
    .on("mouseout",function(d,i){
        d3.select(this)
        .transition()
        .duration(300)
        .attr("d", path);
    })
    .transition()
    .duration(750)
    .delay(10)
    .attr("d", path);

//  Label the Sector with the total number of sector beneficiaries
arc.append("text")
    .attr("transform", function(d) { return "translate(" + secLabel.centroid(d) + ")"; })
    .attr("dy", "0.35em")
    .text(function(d) { return d.data.sector; });

// Label the total number of sector female beneficiaries
arc.append("text")
    .attr("transform", function(d) { return "translate(" + secLabel.centroid(d) + ") translate(0,15)"; })
    .attr("dy", "0.35em")
    .text(function(d) { return numberWithCommas(d.data.totalBeneficiaries); });

// Label the total final beneficiaries
arc.append("text")
    .attr("dy", "0.35em")
    .attr("transform", "translate(0,-15)")
    .text("Total Final");
arc.append("text")
    .attr("dy", "0.35em")
    .text("Beneficiaries");
arc.append("text")
    .attr("dy", "0.35em")
    .attr("transform", "translate(0,15)")
    .text(numberWithCommas(<?php echo e($finBens); ?>));



// Bar chart
// Get the sector beneficiary data
/*var data = <?php echo json_encode( $benBars ) ?>;

// Set the initial sector
var sector = "All"

function selectDataset(group)
{
  var ds = [];
  for (x in datasetBarChart)
  {
      if(datasetBarChart[x].group==group)
      {
 	      ds.push(datasetBarChart[x]);
      }
  }

  return ds;
}*/
</script>
