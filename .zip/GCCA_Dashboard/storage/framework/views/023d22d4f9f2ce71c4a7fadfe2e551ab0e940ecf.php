<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
