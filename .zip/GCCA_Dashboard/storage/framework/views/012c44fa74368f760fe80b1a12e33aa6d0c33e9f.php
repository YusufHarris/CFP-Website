<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>CFP Dashboard</title>

    <!-- JQuery -->
    <script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>

    <!-- Leaflet CSS and Javascript -->
    <link rel="stylesheet" href="<?php echo e(asset('css/leaflet.css')); ?>"/>
    <script src="<?php echo e(asset('js/leaflet.js')); ?>"></script>

    <!-- D3 core Javascript -->
    <script src="<?php echo e(asset('js/d3.v5.js')); ?>"></script>
    <!-- Chart Class for quickly creating resizable D3 charts -->
    <script src="<?php echo e(asset('js/ChartClass.js')); ?>"></script>

    <!-- Custom styles for this template -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dashboard.css')); ?>"/>

  </head>
    <body>
        <?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>
